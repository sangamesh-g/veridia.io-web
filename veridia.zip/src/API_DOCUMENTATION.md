# TalentHub Recruitment System - Backend API Documentation

## Table of Contents
1. [Overview](#overview)
2. [Base URL](#base-url)
3. [Authentication](#authentication)
4. [API Endpoints](#api-endpoints)
5. [Data Models](#data-models)
6. [Email Notifications](#email-notifications)
7. [File Upload](#file-upload)
8. [Error Handling](#error-handling)
9. [Django Implementation Guide](#django-implementation-guide)

---

## Overview

This document provides complete specifications for the REST API endpoints required for the TalentHub Recruitment Management System. The backend should be built using Django REST Framework.

### Technology Stack Requirements
- **Backend Framework**: Django 4.x + Django REST Framework
- **Database**: PostgreSQL (recommended) or MySQL
- **Authentication**: JWT (JSON Web Tokens) or Django Session Authentication
- **File Storage**: Django's FileField with cloud storage (AWS S3, etc.)
- **Email**: Django Email Backend (SMTP)
- **CORS**: django-cors-headers for cross-origin requests

---

## Base URL

```
Production: https://api.talenthub.com/api/v1
Development: http://localhost:8000/api/v1
```

All endpoints below are relative to the base URL.

---

## Authentication

### 1. User Registration (Applicant)

**Endpoint**: `POST /auth/register/`

**Request Body**:
```json
{
  "email": "john.doe@example.com",
  "password": "SecurePass123!",
  "password_confirm": "SecurePass123!",
  "first_name": "John",
  "last_name": "Doe",
  "phone": "+1 (555) 123-4567",
  "user_type": "applicant"
}
```

**Response** (201 Created):
```json
{
  "success": true,
  "message": "Registration successful. Please check your email for verification.",
  "data": {
    "user_id": 1,
    "email": "john.doe@example.com",
    "first_name": "John",
    "last_name": "Doe",
    "user_type": "applicant",
    "is_verified": false
  }
}
```

**Email Trigger**: Send verification email with link

---

### 2. User Login

**Endpoint**: `POST /auth/login/`

**Request Body**:
```json
{
  "email": "john.doe@example.com",
  "password": "SecurePass123!"
}
```

**Response** (200 OK):
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "user": {
      "user_id": 1,
      "email": "john.doe@example.com",
      "first_name": "John",
      "last_name": "Doe",
      "user_type": "applicant",
      "is_verified": true,
      "profile_completed": true
    }
  }
}
```

**Response for Admin** (200 OK):
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "user": {
      "user_id": 5,
      "email": "admin@talenthub.com",
      "first_name": "Admin",
      "last_name": "User",
      "user_type": "admin",
      "is_verified": true,
      "permissions": ["view_applications", "edit_applications", "create_applications", "delete_applications"]
    }
  }
}
```

---

### 3. Logout

**Endpoint**: `POST /auth/logout/`

**Headers**: 
```
Authorization: Bearer {access_token}
```

**Request Body**:
```json
{
  "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**Response** (200 OK):
```json
{
  "success": true,
  "message": "Logged out successfully"
}
```

---

### 4. Token Refresh

**Endpoint**: `POST /auth/token/refresh/`

**Request Body**:
```json
{
  "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**Response** (200 OK):
```json
{
  "success": true,
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

---

### 5. Password Reset Request

**Endpoint**: `POST /auth/password-reset/`

**Request Body**:
```json
{
  "email": "john.doe@example.com"
}
```

**Response** (200 OK):
```json
{
  "success": true,
  "message": "Password reset instructions sent to your email"
}
```

**Email Trigger**: Send password reset link

---

### 6. Password Reset Confirm

**Endpoint**: `POST /auth/password-reset/confirm/`

**Request Body**:
```json
{
  "token": "reset_token_from_email",
  "new_password": "NewSecurePass123!",
  "new_password_confirm": "NewSecurePass123!"
}
```

**Response** (200 OK):
```json
{
  "success": true,
  "message": "Password has been reset successfully"
}
```

---

## API Endpoints

### APPLICANT ENDPOINTS

#### 1. Get Applicant Dashboard Stats

**Endpoint**: `GET /applicant/dashboard/stats/`

**Headers**: 
```
Authorization: Bearer {access_token}
```

**Response** (200 OK):
```json
{
  "success": true,
  "data": {
    "total_applications": 3,
    "pending_review": 1,
    "interviews_scheduled": 1,
    "rejected": 1,
    "accepted": 0,
    "response_rate": 67
  }
}
```

---

#### 2. Submit New Application

**Endpoint**: `POST /applicant/applications/`

**Headers**: 
```
Authorization: Bearer {access_token}
Content-Type: multipart/form-data
```

**Request Body** (FormData):
```javascript
{
  "position": "Software Engineer",
  "department": "Engineering",
  "experience": "5 years",
  "expected_salary": "$90,000",
  "education": "Bachelor's Degree in Computer Science",
  "skills": "React, TypeScript, Node.js, Python",
  "linkedin_url": "https://linkedin.com/in/johndoe",
  "portfolio_url": "https://johndoe.com",
  "cover_letter": "I am writing to express my interest...",
  "resume": File // PDF, DOC, DOCX
}
```

**Response** (201 Created):
```json
{
  "success": true,
  "message": "Application submitted successfully",
  "data": {
    "application_id": 15,
    "position": "Software Engineer",
    "department": "Engineering",
    "status": "under-review",
    "applied_date": "2025-12-03T10:30:00Z",
    "resume_url": "https://storage.talenthub.com/resumes/john_doe_resume.pdf"
  }
}
```

**Email Trigger**: 
- Send confirmation email to applicant
- Send notification email to HR team

---

#### 3. Get All Applicant's Applications

**Endpoint**: `GET /applicant/applications/`

**Headers**: 
```
Authorization: Bearer {access_token}
```

**Query Parameters**:
- `status` (optional): "under-review", "interview-scheduled", "accepted", "rejected"
- `page` (optional): 1, 2, 3...
- `page_size` (optional): 10, 20, 50

**Example**: `/applicant/applications/?status=under-review&page=1&page_size=10`

**Response** (200 OK):
```json
{
  "success": true,
  "data": {
    "count": 3,
    "next": null,
    "previous": null,
    "results": [
      {
        "application_id": 15,
        "position": "Software Engineer",
        "department": "Engineering",
        "experience": "5 years",
        "expected_salary": "$90,000",
        "status": "under-review",
        "applied_date": "2025-11-15T10:30:00Z",
        "last_updated": "2025-11-15T10:30:00Z",
        "resume_url": "https://storage.talenthub.com/resumes/john_doe_resume.pdf",
        "interview_date": null,
        "notes": null
      },
      {
        "application_id": 14,
        "position": "Senior Developer",
        "department": "Engineering",
        "experience": "5 years",
        "expected_salary": "$95,000",
        "status": "interview-scheduled",
        "applied_date": "2025-10-20T14:20:00Z",
        "last_updated": "2025-11-01T09:15:00Z",
        "resume_url": "https://storage.talenthub.com/resumes/john_doe_resume_v2.pdf",
        "interview_date": "2025-12-05T10:00:00Z",
        "notes": "Technical interview with engineering team"
      }
    ]
  }
}
```

---

#### 4. Get Single Application Details

**Endpoint**: `GET /applicant/applications/{application_id}/`

**Headers**: 
```
Authorization: Bearer {access_token}
```

**Response** (200 OK):
```json
{
  "success": true,
  "data": {
    "application_id": 15,
    "applicant": {
      "user_id": 1,
      "first_name": "John",
      "last_name": "Doe",
      "email": "john.doe@example.com",
      "phone": "+1 (555) 123-4567"
    },
    "position": "Software Engineer",
    "department": "Engineering",
    "experience": "5 years",
    "expected_salary": "$90,000",
    "education": "Bachelor's Degree in Computer Science",
    "skills": "React, TypeScript, Node.js, Python",
    "linkedin_url": "https://linkedin.com/in/johndoe",
    "portfolio_url": "https://johndoe.com",
    "cover_letter": "I am writing to express my interest...",
    "status": "under-review",
    "applied_date": "2025-11-15T10:30:00Z",
    "last_updated": "2025-11-15T10:30:00Z",
    "resume_url": "https://storage.talenthub.com/resumes/john_doe_resume.pdf",
    "interview_date": null,
    "notes": null,
    "status_history": [
      {
        "status": "under-review",
        "changed_by": "System",
        "changed_at": "2025-11-15T10:30:00Z",
        "comment": "Application submitted"
      }
    ]
  }
}
```

---

#### 5. Withdraw Application

**Endpoint**: `DELETE /applicant/applications/{application_id}/`

**Headers**: 
```
Authorization: Bearer {access_token}
```

**Response** (200 OK):
```json
{
  "success": true,
  "message": "Application withdrawn successfully"
}
```

**Email Trigger**: Send notification to HR team

---

#### 6. Get Applicant Profile

**Endpoint**: `GET /applicant/profile/`

**Headers**: 
```
Authorization: Bearer {access_token}
```

**Response** (200 OK):
```json
{
  "success": true,
  "data": {
    "user_id": 1,
    "email": "john.doe@example.com",
    "first_name": "John",
    "last_name": "Doe",
    "phone": "+1 (555) 123-4567",
    "date_of_birth": "1990-05-15",
    "address": "123 Main St, City, State 12345",
    "linkedin_url": "https://linkedin.com/in/johndoe",
    "portfolio_url": "https://johndoe.com",
    "bio": "Experienced software engineer with 5 years...",
    "profile_picture": "https://storage.talenthub.com/profiles/john_doe.jpg",
    "created_at": "2025-10-01T08:00:00Z",
    "updated_at": "2025-11-01T10:30:00Z"
  }
}
```

---

#### 7. Update Applicant Profile

**Endpoint**: `PUT /applicant/profile/` or `PATCH /applicant/profile/`

**Headers**: 
```
Authorization: Bearer {access_token}
Content-Type: multipart/form-data (if uploading profile picture)
```

**Request Body**:
```json
{
  "first_name": "John",
  "last_name": "Doe",
  "phone": "+1 (555) 123-4567",
  "date_of_birth": "1990-05-15",
  "address": "123 Main St, City, State 12345",
  "linkedin_url": "https://linkedin.com/in/johndoe",
  "portfolio_url": "https://johndoe.com",
  "bio": "Experienced software engineer with 5 years...",
  "profile_picture": File // Optional
}
```

**Response** (200 OK):
```json
{
  "success": true,
  "message": "Profile updated successfully",
  "data": {
    "user_id": 1,
    "email": "john.doe@example.com",
    "first_name": "John",
    "last_name": "Doe",
    "phone": "+1 (555) 123-4567",
    "profile_picture": "https://storage.talenthub.com/profiles/john_doe.jpg",
    "updated_at": "2025-12-03T10:30:00Z"
  }
}
```

---

### ADMIN/HR ENDPOINTS

#### 8. Get Admin Dashboard Stats

**Endpoint**: `GET /admin/dashboard/stats/`

**Headers**: 
```
Authorization: Bearer {access_token}
```

**Response** (200 OK):
```json
{
  "success": true,
  "data": {
    "total_applications": 25,
    "pending_review": 8,
    "interviews_scheduled": 5,
    "accepted": 4,
    "rejected": 8,
    "avg_time_to_hire": 21,
    "acceptance_rate": 16,
    "interview_conversion_rate": 80,
    "active_positions": 8,
    "department_stats": [
      {
        "department": "Engineering",
        "count": 12,
        "percentage": 48
      },
      {
        "department": "Product",
        "count": 6,
        "percentage": 24
      },
      {
        "department": "Design",
        "count": 4,
        "percentage": 16
      },
      {
        "department": "Marketing",
        "count": 3,
        "percentage": 12
      }
    ]
  }
}
```

---

#### 9. Get All Applications (Admin View)

**Endpoint**: `GET /admin/applications/`

**Headers**: 
```
Authorization: Bearer {access_token}
```

**Query Parameters**:
- `status` (optional): "under-review", "interview-scheduled", "accepted", "rejected"
- `department` (optional): "Engineering", "Product", "Design", "Marketing", "Sales"
- `position` (optional): "Software Engineer", "Senior Developer", etc.
- `search` (optional): Search by candidate name or email
- `date_from` (optional): Filter by application date (YYYY-MM-DD)
- `date_to` (optional): Filter by application date (YYYY-MM-DD)
- `page` (optional): 1, 2, 3...
- `page_size` (optional): 10, 20, 50
- `ordering` (optional): "applied_date", "-applied_date", "status"

**Example**: `/admin/applications/?status=under-review&department=Engineering&page=1&page_size=10&ordering=-applied_date`

**Response** (200 OK):
```json
{
  "success": true,
  "data": {
    "count": 25,
    "next": "http://localhost:8000/api/v1/admin/applications/?page=2",
    "previous": null,
    "results": [
      {
        "application_id": 15,
        "applicant": {
          "user_id": 1,
          "first_name": "John",
          "last_name": "Doe",
          "email": "john.doe@example.com",
          "phone": "+1 (555) 123-4567",
          "profile_picture": "https://storage.talenthub.com/profiles/john_doe.jpg"
        },
        "position": "Software Engineer",
        "department": "Engineering",
        "experience": "5 years",
        "expected_salary": "$90,000",
        "status": "under-review",
        "applied_date": "2025-11-15T10:30:00Z",
        "last_updated": "2025-11-15T10:30:00Z",
        "resume_url": "https://storage.talenthub.com/resumes/john_doe_resume.pdf",
        "interview_date": null
      }
    ]
  }
}
```

---

#### 10. Get Single Application (Admin View)

**Endpoint**: `GET /admin/applications/{application_id}/`

**Headers**: 
```
Authorization: Bearer {access_token}
```

**Response** (200 OK):
```json
{
  "success": true,
  "data": {
    "application_id": 15,
    "applicant": {
      "user_id": 1,
      "first_name": "John",
      "last_name": "Doe",
      "email": "john.doe@example.com",
      "phone": "+1 (555) 123-4567",
      "date_of_birth": "1990-05-15",
      "address": "123 Main St, City, State 12345",
      "profile_picture": "https://storage.talenthub.com/profiles/john_doe.jpg"
    },
    "position": "Software Engineer",
    "department": "Engineering",
    "experience": "5 years",
    "expected_salary": "$90,000",
    "education": "Bachelor's Degree in Computer Science",
    "skills": "React, TypeScript, Node.js, Python",
    "linkedin_url": "https://linkedin.com/in/johndoe",
    "portfolio_url": "https://johndoe.com",
    "cover_letter": "I am writing to express my interest...",
    "status": "under-review",
    "applied_date": "2025-11-15T10:30:00Z",
    "last_updated": "2025-11-15T10:30:00Z",
    "resume_url": "https://storage.talenthub.com/resumes/john_doe_resume.pdf",
    "interview_date": null,
    "notes": "Strong technical background. Recommended for interview.",
    "status_history": [
      {
        "status": "under-review",
        "changed_by": "System",
        "changed_at": "2025-11-15T10:30:00Z",
        "comment": "Application submitted"
      }
    ]
  }
}
```

---

#### 11. Create New Application (Admin)

**Endpoint**: `POST /admin/applications/`

**Headers**: 
```
Authorization: Bearer {access_token}
Content-Type: multipart/form-data
```

**Request Body** (FormData):
```javascript
{
  // Applicant Information
  "first_name": "Jane",
  "last_name": "Smith",
  "email": "jane.smith@example.com",
  "phone": "+1 (555) 987-6543",
  
  // Application Details
  "position": "Senior Developer",
  "department": "Engineering",
  "experience": "7 years",
  "expected_salary": "$110,000",
  "education": "Master's Degree in Computer Science",
  "skills": "Python, Django, AWS, Docker",
  "linkedin_url": "https://linkedin.com/in/janesmith",
  "portfolio_url": "https://janesmith.com",
  "cover_letter": "I am excited to apply...",
  "status": "under-review", // Optional, defaults to "under-review"
  "notes": "Referred by current employee", // Optional
  "resume": File // PDF, DOC, DOCX
}
```

**Response** (201 Created):
```json
{
  "success": true,
  "message": "Application created successfully",
  "data": {
    "application_id": 26,
    "applicant": {
      "user_id": 15,
      "first_name": "Jane",
      "last_name": "Smith",
      "email": "jane.smith@example.com",
      "phone": "+1 (555) 987-6543"
    },
    "position": "Senior Developer",
    "department": "Engineering",
    "status": "under-review",
    "applied_date": "2025-12-03T10:30:00Z",
    "resume_url": "https://storage.talenthub.com/resumes/jane_smith_resume.pdf"
  }
}
```

**Email Trigger**: Send welcome email to new applicant with temporary credentials

---

#### 12. Update Application (Admin)

**Endpoint**: `PUT /admin/applications/{application_id}/` or `PATCH /admin/applications/{application_id}/`

**Headers**: 
```
Authorization: Bearer {access_token}
Content-Type: application/json
```

**Request Body** (JSON):
```json
{
  "position": "Senior Software Engineer",
  "department": "Engineering",
  "experience": "5 years",
  "expected_salary": "$95,000",
  "education": "Bachelor's Degree in Computer Science",
  "skills": "React, TypeScript, Node.js, Python, AWS",
  "linkedin_url": "https://linkedin.com/in/johndoe",
  "portfolio_url": "https://johndoe.com",
  "cover_letter": "Updated cover letter...",
  "status": "interview-scheduled",
  "interview_date": "2025-12-10T14:00:00Z",
  "notes": "Moved to interview stage. Technical round scheduled."
}
```

**Response** (200 OK):
```json
{
  "success": true,
  "message": "Application updated successfully",
  "data": {
    "application_id": 15,
    "position": "Senior Software Engineer",
    "status": "interview-scheduled",
    "interview_date": "2025-12-10T14:00:00Z",
    "last_updated": "2025-12-03T10:30:00Z"
  }
}
```

**Email Trigger**: 
- If status changed to "interview-scheduled": Send interview invitation email
- If status changed to "accepted": Send acceptance email
- If status changed to "rejected": Send rejection email (polite)

---

#### 13. Update Application Status

**Endpoint**: `PATCH /admin/applications/{application_id}/status/`

**Headers**: 
```
Authorization: Bearer {access_token}
Content-Type: application/json
```

**Request Body**:
```json
{
  "status": "interview-scheduled",
  "interview_date": "2025-12-10T14:00:00Z",
  "notes": "Technical interview with senior team members",
  "comment": "Candidate shows strong potential"
}
```

**Response** (200 OK):
```json
{
  "success": true,
  "message": "Application status updated successfully",
  "data": {
    "application_id": 15,
    "status": "interview-scheduled",
    "interview_date": "2025-12-10T14:00:00Z",
    "last_updated": "2025-12-03T10:30:00Z"
  }
}
```

**Email Trigger**: Based on status change

---

#### 14. Delete Application (Admin)

**Endpoint**: `DELETE /admin/applications/{application_id}/`

**Headers**: 
```
Authorization: Bearer {access_token}
```

**Response** (200 OK):
```json
{
  "success": true,
  "message": "Application deleted successfully"
}
```

---

#### 15. Get Recent Activity (Admin)

**Endpoint**: `GET /admin/activity/`

**Headers**: 
```
Authorization: Bearer {access_token}
```

**Query Parameters**:
- `limit` (optional): Number of recent activities (default: 20)

**Response** (200 OK):
```json
{
  "success": true,
  "data": [
    {
      "activity_id": 150,
      "action": "application_submitted",
      "description": "New application received",
      "applicant": {
        "user_id": 1,
        "first_name": "John",
        "last_name": "Doe"
      },
      "position": "Software Engineer",
      "timestamp": "2025-12-03T08:30:00Z"
    },
    {
      "activity_id": 149,
      "action": "status_changed",
      "description": "Application status changed to interview-scheduled",
      "applicant": {
        "user_id": 2,
        "first_name": "Jane",
        "last_name": "Smith"
      },
      "position": "Senior Developer",
      "changed_by": "Admin User",
      "timestamp": "2025-12-02T15:20:00Z"
    }
  ]
}
```

---

#### 16. Get Upcoming Interviews (Admin)

**Endpoint**: `GET /admin/interviews/upcoming/`

**Headers**: 
```
Authorization: Bearer {access_token}
```

**Response** (200 OK):
```json
{
  "success": true,
  "data": [
    {
      "interview_id": 10,
      "application_id": 14,
      "applicant": {
        "user_id": 2,
        "first_name": "Jane",
        "last_name": "Smith",
        "email": "jane.smith@example.com",
        "phone": "+1 (555) 987-6543"
      },
      "position": "Senior Developer",
      "department": "Engineering",
      "interview_date": "2025-12-05T10:00:00Z",
      "interview_type": "technical",
      "interviewer": "Senior Engineering Manager",
      "location": "Office - Conference Room A",
      "notes": "Technical assessment"
    }
  ]
}
```

---

#### 17. Get Analytics Data (Admin)

**Endpoint**: `GET /admin/analytics/`

**Headers**: 
```
Authorization: Bearer {access_token}
```

**Query Parameters**:
- `start_date` (optional): YYYY-MM-DD
- `end_date` (optional): YYYY-MM-DD

**Response** (200 OK):
```json
{
  "success": true,
  "data": {
    "overview": {
      "total_applications": 150,
      "total_applicants": 125,
      "acceptance_rate": 16.5,
      "avg_time_to_hire": 21
    },
    "applications_by_month": [
      {
        "month": "2025-08",
        "count": 20
      },
      {
        "month": "2025-09",
        "count": 25
      },
      {
        "month": "2025-10",
        "count": 30
      },
      {
        "month": "2025-11",
        "count": 35
      }
    ],
    "applications_by_status": {
      "under-review": 45,
      "interview-scheduled": 30,
      "accepted": 25,
      "rejected": 50
    },
    "applications_by_department": {
      "Engineering": 60,
      "Product": 30,
      "Design": 20,
      "Marketing": 25,
      "Sales": 15
    },
    "top_positions": [
      {
        "position": "Software Engineer",
        "count": 45
      },
      {
        "position": "Senior Developer",
        "count": 30
      },
      {
        "position": "Product Manager",
        "count": 20
      }
    ]
  }
}
```

---

#### 18. Get Admin Settings

**Endpoint**: `GET /admin/settings/`

**Headers**: 
```
Authorization: Bearer {access_token}
```

**Response** (200 OK):
```json
{
  "success": true,
  "data": {
    "email_notifications": {
      "new_application": true,
      "status_change": true,
      "interview_reminder": true
    },
    "auto_response": {
      "enabled": true,
      "message": "Thank you for your application. We will review it and get back to you soon."
    },
    "application_form": {
      "required_fields": ["first_name", "last_name", "email", "phone", "position", "resume"],
      "optional_fields": ["linkedin_url", "portfolio_url", "cover_letter"]
    },
    "positions": [
      {
        "id": 1,
        "title": "Software Engineer",
        "department": "Engineering",
        "is_active": true
      },
      {
        "id": 2,
        "title": "Senior Developer",
        "department": "Engineering",
        "is_active": true
      }
    ]
  }
}
```

---

#### 19. Update Admin Settings

**Endpoint**: `PUT /admin/settings/` or `PATCH /admin/settings/`

**Headers**: 
```
Authorization: Bearer {access_token}
Content-Type: application/json
```

**Request Body**:
```json
{
  "email_notifications": {
    "new_application": true,
    "status_change": true,
    "interview_reminder": false
  },
  "auto_response": {
    "enabled": true,
    "message": "Thank you for applying to TalentHub..."
  }
}
```

**Response** (200 OK):
```json
{
  "success": true,
  "message": "Settings updated successfully"
}
```

---

### COMMON ENDPOINTS

#### 20. Get Available Positions

**Endpoint**: `GET /positions/`

**Response** (200 OK):
```json
{
  "success": true,
  "data": [
    {
      "position_id": 1,
      "title": "Software Engineer",
      "department": "Engineering",
      "description": "We are looking for a talented software engineer...",
      "requirements": ["Bachelor's degree", "3+ years experience", "React, Node.js"],
      "is_active": true
    },
    {
      "position_id": 2,
      "title": "Senior Developer",
      "department": "Engineering",
      "description": "Join our team as a senior developer...",
      "requirements": ["Bachelor's degree", "5+ years experience", "Full stack"],
      "is_active": true
    }
  ]
}
```

---

#### 21. Get Departments

**Endpoint**: `GET /departments/`

**Response** (200 OK):
```json
{
  "success": true,
  "data": [
    {
      "department_id": 1,
      "name": "Engineering",
      "description": "Software development and technical teams"
    },
    {
      "department_id": 2,
      "name": "Product",
      "description": "Product management and strategy"
    },
    {
      "department_id": 3,
      "name": "Design",
      "description": "UI/UX and creative design"
    },
    {
      "department_id": 4,
      "name": "Marketing",
      "description": "Marketing and communications"
    },
    {
      "department_id": 5,
      "name": "Sales",
      "description": "Sales and business development"
    }
  ]
}
```

---

## Data Models

### User Model
```python
class User(AbstractBaseUser):
    user_id: Integer (Primary Key, Auto)
    email: String (Unique, Required)
    password: String (Hashed, Required)
    first_name: String (Required)
    last_name: String (Required)
    phone: String (Required)
    user_type: Enum ['applicant', 'admin'] (Required)
    is_verified: Boolean (Default: False)
    is_active: Boolean (Default: True)
    profile_picture: File/URL (Optional)
    date_of_birth: Date (Optional)
    address: Text (Optional)
    linkedin_url: URL (Optional)
    portfolio_url: URL (Optional)
    bio: Text (Optional)
    created_at: DateTime (Auto)
    updated_at: DateTime (Auto)
```

### Application Model
```python
class Application:
    application_id: Integer (Primary Key, Auto)
    applicant: ForeignKey(User) (Required)
    position: String (Required)
    department: String (Required)
    experience: String (Optional)
    expected_salary: String (Optional)
    education: String (Optional)
    skills: Text (Optional)
    linkedin_url: URL (Optional)
    portfolio_url: URL (Optional)
    cover_letter: Text (Optional)
    resume: File (Required)
    status: Enum ['under-review', 'interview-scheduled', 'accepted', 'rejected'] (Default: 'under-review')
    interview_date: DateTime (Optional)
    notes: Text (Optional, Admin Only)
    applied_date: DateTime (Auto)
    last_updated: DateTime (Auto)
```

### StatusHistory Model
```python
class StatusHistory:
    history_id: Integer (Primary Key, Auto)
    application: ForeignKey(Application) (Required)
    status: String (Required)
    changed_by: ForeignKey(User) (Required)
    changed_at: DateTime (Auto)
    comment: Text (Optional)
```

### Position Model
```python
class Position:
    position_id: Integer (Primary Key, Auto)
    title: String (Required)
    department: ForeignKey(Department) (Required)
    description: Text (Required)
    requirements: JSON/Text (Optional)
    is_active: Boolean (Default: True)
    created_at: DateTime (Auto)
    updated_at: DateTime (Auto)
```

### Department Model
```python
class Department:
    department_id: Integer (Primary Key, Auto)
    name: String (Required, Unique)
    description: Text (Optional)
    created_at: DateTime (Auto)
```

### Activity Model
```python
class Activity:
    activity_id: Integer (Primary Key, Auto)
    action: String (Required)
    description: Text (Required)
    applicant: ForeignKey(User) (Optional)
    application: ForeignKey(Application) (Optional)
    changed_by: ForeignKey(User) (Optional)
    timestamp: DateTime (Auto)
    metadata: JSON (Optional)
```

---

## Email Notifications

### Email Templates Required

1. **Registration Confirmation**
   - Trigger: User registration
   - To: New applicant
   - Subject: "Welcome to TalentHub - Verify Your Email"
   - Content: Verification link, welcome message

2. **Application Submission Confirmation**
   - Trigger: New application submitted
   - To: Applicant
   - Subject: "Application Received - [Position Name]"
   - Content: Application details, what to expect next

3. **Application Status Update**
   - Trigger: Status changed
   - To: Applicant
   - Subject: "Update on Your Application - [Position Name]"
   - Content: New status, next steps

4. **Interview Invitation**
   - Trigger: Status changed to "interview-scheduled"
   - To: Applicant
   - Subject: "Interview Invitation - [Position Name]"
   - Content: Interview date, time, location, instructions

5. **Acceptance Email**
   - Trigger: Status changed to "accepted"
   - To: Applicant
   - Subject: "Congratulations! Offer Letter - [Position Name]"
   - Content: Congratulations message, next steps

6. **Rejection Email**
   - Trigger: Status changed to "rejected"
   - To: Applicant
   - Subject: "Application Update - [Position Name]"
   - Content: Polite rejection, encouragement

7. **New Application Alert (Admin)**
   - Trigger: New application submitted
   - To: HR team
   - Subject: "New Application Received - [Position Name]"
   - Content: Applicant summary, link to review

8. **Interview Reminder (Admin)**
   - Trigger: 1 day before interview
   - To: HR team/Interviewer
   - Subject: "Interview Reminder - [Candidate Name]"
   - Content: Interview details, candidate summary

---

## File Upload

### File Upload Specifications

**Resume/CV Upload**:
- Endpoint: Part of application submission/creation
- Accepted formats: PDF, DOC, DOCX
- Max file size: 5MB
- Storage: Cloud storage (AWS S3, Google Cloud Storage, etc.)
- Naming convention: `{user_id}_{timestamp}_{original_name}`
- URL: Return public accessible URL after upload

**Profile Picture Upload**:
- Endpoint: Part of profile update
- Accepted formats: JPG, JPEG, PNG
- Max file size: 2MB
- Storage: Cloud storage
- Naming convention: `profile_{user_id}_{timestamp}.{extension}`
- URL: Return public accessible URL after upload

### Django File Handling
```python
# settings.py
MEDIA_URL = '/media/'
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')

# For production with AWS S3
DEFAULT_FILE_STORAGE = 'storages.backends.s3boto3.S3Boto3Storage'
AWS_ACCESS_KEY_ID = 'your-access-key'
AWS_SECRET_ACCESS_KEY = 'your-secret-key'
AWS_STORAGE_BUCKET_NAME = 'talenthub-files'
AWS_S3_REGION_NAME = 'us-east-1'
```

---

## Error Handling

### Standard Error Response Format

**4xx Client Errors**:
```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid input data",
    "details": {
      "email": ["This field is required"],
      "password": ["Password must be at least 8 characters"]
    }
  }
}
```

**5xx Server Errors**:
```json
{
  "success": false,
  "error": {
    "code": "INTERNAL_SERVER_ERROR",
    "message": "An unexpected error occurred. Please try again later."
  }
}
```

### Common Error Codes

| HTTP Status | Error Code | Description |
|-------------|-----------|-------------|
| 400 | VALIDATION_ERROR | Invalid input data |
| 401 | UNAUTHORIZED | Missing or invalid authentication token |
| 403 | FORBIDDEN | User doesn't have permission |
| 404 | NOT_FOUND | Resource not found |
| 409 | CONFLICT | Resource already exists (e.g., email already registered) |
| 422 | UNPROCESSABLE_ENTITY | Valid format but unprocessable data |
| 429 | RATE_LIMIT_EXCEEDED | Too many requests |
| 500 | INTERNAL_SERVER_ERROR | Server error |
| 503 | SERVICE_UNAVAILABLE | Service temporarily unavailable |

---

## Django Implementation Guide

### Required Django Packages
```txt
Django==4.2.7
djangorestframework==3.14.0
djangorestframework-simplejwt==5.3.0
django-cors-headers==4.3.0
django-filter==23.3
Pillow==10.1.0
python-decouple==3.8
psycopg2-binary==2.9.9
boto3==1.29.7
django-storages==1.14.2
celery==5.3.4
redis==5.0.1
```

### Project Structure
```
backend/
├── manage.py
├── requirements.txt
├── .env
├── talenthub/
│   ├── __init__.py
│   ├── settings.py
│   ├── urls.py
│   ├── wsgi.py
│   └── asgi.py
├── apps/
│   ├── authentication/
│   │   ├── models.py
│   │   ├── serializers.py
│   │   ├── views.py
│   │   ├── urls.py
│   │   └── permissions.py
│   ├── applications/
│   │   ├── models.py
│   │   ├── serializers.py
│   │   ├── views.py
│   │   ├── urls.py
│   │   └── filters.py
│   ├── users/
│   │   ├── models.py
│   │   ├── serializers.py
│   │   ├── views.py
│   │   └── urls.py
│   └── notifications/
│       ├── tasks.py
│       ├── email_templates/
│       └── utils.py
└── media/
    ├── resumes/
    └── profiles/
```

### settings.py Configuration
```python
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    
    # Third party
    'rest_framework',
    'rest_framework_simplejwt',
    'corsheaders',
    'django_filters',
    'storages',
    
    # Local apps
    'apps.authentication',
    'apps.applications',
    'apps.users',
    'apps.notifications',
]

MIDDLEWARE = [
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

# CORS Settings
CORS_ALLOWED_ORIGINS = [
    "http://localhost:3000",
    "http://localhost:5173",
    "https://talenthub.com",
]

# REST Framework Settings
REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': [
        'rest_framework_simplejwt.authentication.JWTAuthentication',
    ],
    'DEFAULT_PERMISSION_CLASSES': [
        'rest_framework.permissions.IsAuthenticated',
    ],
    'DEFAULT_PAGINATION_CLASS': 'rest_framework.pagination.PageNumberPagination',
    'PAGE_SIZE': 10,
    'DEFAULT_FILTER_BACKENDS': [
        'django_filters.rest_framework.DjangoFilterBackend',
        'rest_framework.filters.SearchFilter',
        'rest_framework.filters.OrderingFilter',
    ],
}

# JWT Settings
from datetime import timedelta

SIMPLE_JWT = {
    'ACCESS_TOKEN_LIFETIME': timedelta(hours=1),
    'REFRESH_TOKEN_LIFETIME': timedelta(days=7),
    'ROTATE_REFRESH_TOKENS': True,
    'BLACKLIST_AFTER_ROTATION': True,
}

# Email Settings
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = 'your-email@gmail.com'
EMAIL_HOST_PASSWORD = 'your-app-password'
DEFAULT_FROM_EMAIL = 'noreply@talenthub.com'

# Celery Settings (for async email)
CELERY_BROKER_URL = 'redis://localhost:6379/0'
CELERY_RESULT_BACKEND = 'redis://localhost:6379/0'
```

### URL Configuration (urls.py)
```python
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/v1/auth/', include('apps.authentication.urls')),
    path('api/v1/applicant/', include('apps.applications.urls')),
    path('api/v1/admin/', include('apps.applications.admin_urls')),
    path('api/v1/', include('apps.users.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
```

### Authentication Example
```python
# apps/authentication/views.py
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework_simplejwt.tokens import RefreshToken

@api_view(['POST'])
@permission_classes([AllowAny])
def register(request):
    serializer = UserRegistrationSerializer(data=request.data)
    if serializer.is_valid():
        user = serializer.save()
        # Send verification email
        send_verification_email.delay(user.id)
        return Response({
            'success': True,
            'message': 'Registration successful',
            'data': UserSerializer(user).data
        }, status=status.HTTP_201_CREATED)
    return Response({
        'success': False,
        'error': {
            'code': 'VALIDATION_ERROR',
            'message': 'Invalid input data',
            'details': serializer.errors
        }
    }, status=status.HTTP_400_BAD_REQUEST)
```

### Permissions Example
```python
# apps/applications/permissions.py
from rest_framework import permissions

class IsApplicantOrAdmin(permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        if request.user.user_type == 'admin':
            return True
        return obj.applicant == request.user

class IsAdmin(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user.user_type == 'admin'
```

### Email Task Example (Celery)
```python
# apps/notifications/tasks.py
from celery import shared_task
from django.core.mail import send_mail
from django.template.loader import render_to_string

@shared_task
def send_application_confirmation(application_id):
    application = Application.objects.get(id=application_id)
    subject = f'Application Received - {application.position}'
    message = render_to_string('emails/application_confirmation.html', {
        'applicant': application.applicant,
        'application': application
    })
    send_mail(
        subject,
        message,
        'noreply@talenthub.com',
        [application.applicant.email],
        html_message=message
    )
```

---

## Testing Credentials (for development)

### Applicant Account
```
Email: applicant@test.com
Password: TestPass123!
User Type: applicant
```

### Admin Account
```
Email: admin@test.com
Password: AdminPass123!
User Type: admin
```

---

## Rate Limiting

Implement rate limiting to prevent abuse:
- Authentication endpoints: 5 requests per minute
- Application submission: 3 requests per hour per user
- Other endpoints: 100 requests per hour per user

---

## Security Considerations

1. **Password Requirements**:
   - Minimum 8 characters
   - Must contain uppercase, lowercase, number, and special character
   - Hashed using Django's default hasher (PBKDF2)

2. **File Upload Security**:
   - Validate file types
   - Scan for malware
   - Limit file sizes
   - Use secure random filenames

3. **API Security**:
   - HTTPS only in production
   - CORS properly configured
   - JWT tokens with expiration
   - Input validation and sanitization
   - SQL injection prevention (ORM)

4. **Data Privacy**:
   - GDPR compliance
   - Data encryption at rest
   - Secure data transmission
   - Right to be forgotten (delete account)

---

## Webhooks (Optional - for real-time updates)

**Endpoint**: `POST /webhooks/application-update/`

Frontend can register webhooks to receive real-time notifications when application status changes.

---

## API Versioning

Current version: v1
Base URL includes version: `/api/v1/`

Future versions will use: `/api/v2/`, `/api/v3/`, etc.

---

## Support & Contact

For backend integration support:
- API Documentation: https://api.talenthub.com/docs
- Support Email: dev-support@talenthub.com
- Status Page: https://status.talenthub.com

---

**Last Updated**: December 3, 2025
**Version**: 1.0.0
