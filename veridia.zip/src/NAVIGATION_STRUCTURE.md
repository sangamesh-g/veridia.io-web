# Navigation Structure

This recruitment management system now has **completely separate navigation** for Applicants and HR Admins.

## Authentication Pages (Shared)
- **Login Page** - Separate tabs for Applicant and HR Admin login
- **Registration Page** - For new applicants to create accounts

---

## 🎯 Applicant Portal

### Navigation Menu
Located in the top navigation bar with the following sections:

1. **Dashboard** - Overview and quick stats
2. **My Applications** - View and track all applications
3. **Profile** - View and edit personal information
4. **New Application** - Submit a new job application

### Pages

#### 1. Dashboard (`/components/pages/ApplicantDashboardHome.tsx`)
- Welcome section with personalized greeting
- Statistics cards (Total, Pending, Interviews, Response Rate)
- Recent applications list
- Quick actions panel
- Application tips and resources

#### 2. My Applications (`/components/pages/ApplicantApplicationsPage.tsx`)
- Search and filter applications
- Complete list of all submitted applications
- Status badges with color coding
- Application summary statistics
- Detailed view of each application

#### 3. Profile (`/components/pages/ApplicantProfilePage.tsx`)
- Personal information section
- Professional information section
- Edit mode with save/cancel
- Avatar with initials
- Contact details display

#### 4. New Application (`/components/ApplicationForm.tsx`)
- Multi-section form with:
  - Position information
  - Professional details
  - Education background
  - Skills and portfolio
  - Resume upload
  - Cover letter
- Form validation
- Save as draft option
- Submit functionality

---

## 👔 HR Admin Portal

### Navigation Menu
Located in the top navigation bar with the following sections:

1. **Overview** - Dashboard with key metrics
2. **All Applications** - Manage candidate applications
3. **Analytics** - Reports and insights
4. **Settings** - System configuration

### Pages

#### 1. Overview (`/components/pages/AdminDashboardHome.tsx`)
- Key statistics cards (Total, Pending, Interviews, Accepted)
- Recent activity feed
- Department distribution chart
- Performance metrics
- Upcoming interviews list

#### 2. All Applications (`/components/pages/AdminApplicationsPage.tsx`)
- Advanced filtering (status, department, search)
- Complete applications table
- Quick status updates
- View detailed application modal
- Email and download actions
- Bulk actions capability

#### 3. Analytics (`/components/pages/AdminAnalyticsPage.tsx`)
- Department distribution charts
- Status breakdown visualization
- Monthly trends
- Key performance indicators
- Top positions statistics
- Hiring metrics

#### 4. Settings (`/components/pages/AdminSettingsPage.tsx`)
- Company information management
- Email notification settings
- Application form configuration
- HR team management
- System preferences

---

## 🎨 Design Features

### Applicant Portal
- **Color Scheme**: Indigo and Purple gradients
- **Brand Icon**: Briefcase
- **Style**: Professional, user-friendly, encouraging

### Admin Portal
- **Color Scheme**: Purple and Pink gradients
- **Brand Icon**: Users
- **Style**: Professional, data-driven, efficient

### Common Features
- Responsive design for mobile and desktop
- Toast notifications for user feedback
- Loading states and error handling
- Clean card-based layouts
- Smooth transitions and animations
- Accessible UI components

---

## 🔐 Authentication Flow

```
Login Page
  ├── Applicant Tab → Applicant Portal (Dashboard)
  └── Admin Tab → Admin Portal (Overview)

Register Page → Login Page → Applicant Portal
```

## 📱 Mobile Responsiveness

Both portals include:
- Collapsible mobile navigation
- Touch-friendly buttons
- Responsive grid layouts
- Horizontal scrolling for overflow content
- Optimized spacing for small screens

---

## 🔄 Navigation Flow

### Applicant
```
Dashboard ←→ Applications ←→ Profile ←→ New Application
     ↓
  Logout → Login Page
```

### Admin
```
Overview ←→ Applications ←→ Analytics ←→ Settings
    ↓
Logout → Login Page
```

---

## 🚀 Key Benefits

1. **Separation of Concerns** - Each role has its own dedicated interface
2. **Clear Navigation** - Easy to understand menu structure
3. **Role-Based Access** - Appropriate features for each user type
4. **Professional Design** - Distinct branding for each portal
5. **Scalable Structure** - Easy to add new pages and features
6. **Consistent UX** - Familiar patterns across all pages
