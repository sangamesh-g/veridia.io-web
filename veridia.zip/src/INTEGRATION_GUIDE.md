# Django Backend Integration Guide

This React application is ready to be connected to your Django backend. Below are the integration points and API endpoints you'll need to implement.

## Authentication Endpoints

### 1. User Registration
**File:** `/components/Register.tsx`
**Function:** `handleSubmit`

```javascript
// POST /api/auth/register/
{
  "first_name": "John",
  "last_name": "Doe",
  "email": "john.doe@example.com",
  "phone": "+1 (555) 000-0000",
  "password": "password123"
}
```

### 2. User Login
**Files:** `/components/Login.tsx`
**Functions:** `handleApplicantLogin`, `handleAdminLogin`

```javascript
// POST /api/auth/login/
{
  "email": "user@example.com",
  "password": "password123",
  "role": "applicant" // or "admin"
}

// Response should include:
{
  "token": "jwt_token_here",
  "user": {
    "id": 1,
    "role": "applicant",
    "email": "user@example.com"
  }
}
```

## Application Endpoints

### 3. Submit Application
**File:** `/components/ApplicationForm.tsx`
**Function:** `handleSubmit`

```javascript
// POST /api/applications/
// Content-Type: multipart/form-data
{
  "position": "Software Engineer",
  "department": "Engineering",
  "experience": "5 years",
  "current_company": "ABC Corp",
  "current_salary": "$80,000",
  "expected_salary": "$90,000",
  "notice_period": "1-month",
  "education": "bachelor",
  "university": "University of Example",
  "graduation_year": 2020,
  "skills": "React, TypeScript, Node.js",
  "linkedin": "https://linkedin.com/in/profile",
  "portfolio": "https://portfolio.com",
  "cover_letter": "Cover letter text...",
  "referral": "job-board",
  "resume": File
}
```

### 4. Get Applicant Applications
**File:** `/components/ApplicantDashboard.tsx`
**On component mount**

```javascript
// GET /api/applications/user/
// Returns array of applications for logged-in user
[
  {
    "id": 1,
    "position": "Software Engineer",
    "department": "Engineering",
    "applied_date": "2025-11-15",
    "status": "under-review",
    "last_update": "2025-11-28",
    "interview_date": null
  }
]
```

### 5. Get User Profile
**File:** `/components/ApplicantDashboard.tsx`

```javascript
// GET /api/users/profile/
{
  "first_name": "John",
  "last_name": "Doe",
  "email": "john.doe@example.com",
  "phone": "+1 (555) 123-4567",
  "location": "San Francisco, CA",
  "education": "Bachelor's Degree",
  "experience": "5 years",
  "skills": "React, TypeScript, Node.js",
  "linkedin": "linkedin.com/in/johndoe"
}
```

### 6. Update User Profile
**File:** `/components/ProfileEditModal.tsx`
**Function:** `handleSubmit`

```javascript
// PUT /api/users/profile/
{
  "first_name": "John",
  "last_name": "Doe",
  "email": "john.doe@example.com",
  "phone": "+1 (555) 123-4567",
  "location": "San Francisco, CA",
  "education": "Bachelor's Degree",
  "experience": "5 years",
  "skills": "React, TypeScript, Node.js",
  "linkedin": "linkedin.com/in/johndoe"
}
```

## Admin Endpoints

### 7. Get All Applications (Admin)
**File:** `/components/AdminDashboard.tsx`
**On component mount**

```javascript
// GET /api/admin/applications/
// Optional query parameters: ?status=under-review&department=Engineering&search=john
[
  {
    "id": 1,
    "candidate_name": "John Doe",
    "email": "john.doe@example.com",
    "phone": "+1 (555) 123-4567",
    "position": "Software Engineer",
    "department": "Engineering",
    "experience": "5 years",
    "expected_salary": "$90,000",
    "applied_date": "2025-11-15",
    "status": "under-review",
    "skills": "React, TypeScript, Node.js",
    "education": "Bachelor's Degree",
    "resume": "url_to_resume.pdf"
  }
]
```

### 8. Update Application Status (Admin)
**File:** `/components/AdminDashboard.tsx`
**Function:** `handleStatusChange`

```javascript
// PATCH /api/admin/applications/{id}/
{
  "status": "interview-scheduled"
}
```

### 9. Get Application Details (Admin)
**File:** `/components/AdminDashboard.tsx`
**Function:** `handleViewDetails`

```javascript
// GET /api/admin/applications/{id}/
{
  "id": 1,
  "candidate_name": "John Doe",
  "email": "john.doe@example.com",
  "phone": "+1 (555) 123-4567",
  "position": "Software Engineer",
  "department": "Engineering",
  "experience": "5 years",
  "expected_salary": "$90,000",
  "applied_date": "2025-11-15",
  "status": "under-review",
  "skills": "React, TypeScript, Node.js",
  "education": "Bachelor's Degree",
  "cover_letter": "Full cover letter text...",
  "resume": "url_to_resume.pdf",
  "current_company": "ABC Corp",
  "current_salary": "$80,000",
  "notice_period": "1-month",
  "university": "University of Example",
  "graduation_year": 2020,
  "linkedin": "https://linkedin.com/in/profile",
  "portfolio": "https://portfolio.com",
  "referral": "job-board"
}
```

## Email Notifications

The following actions should trigger automated email notifications from your Django backend:

1. **Application Submission** - Send confirmation email to applicant
2. **Status Change to "Interview Scheduled"** - Send interview invitation
3. **Status Change to "Accepted"** - Send acceptance/offer letter
4. **Status Change to "Rejected"** - Send rejection notice

## Django Models Suggestion

```python
# models.py

class User(AbstractUser):
    ROLE_CHOICES = [
        ('applicant', 'Applicant'),
        ('admin', 'Admin'),
    ]
    role = models.CharField(max_length=10, choices=ROLE_CHOICES)
    phone = models.CharField(max_length=20, blank=True)
    location = models.CharField(max_length=200, blank=True)
    linkedin = models.URLField(blank=True)

class Application(models.Model):
    STATUS_CHOICES = [
        ('under-review', 'Under Review'),
        ('interview-scheduled', 'Interview Scheduled'),
        ('accepted', 'Accepted'),
        ('rejected', 'Rejected'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    position = models.CharField(max_length=200)
    department = models.CharField(max_length=100)
    experience = models.CharField(max_length=50)
    current_company = models.CharField(max_length=200, blank=True)
    current_salary = models.CharField(max_length=50, blank=True)
    expected_salary = models.CharField(max_length=50)
    notice_period = models.CharField(max_length=50)
    education = models.CharField(max_length=100)
    university = models.CharField(max_length=200)
    graduation_year = models.IntegerField()
    skills = models.TextField()
    linkedin = models.URLField(blank=True)
    portfolio = models.URLField(blank=True)
    cover_letter = models.TextField()
    referral = models.CharField(max_length=100, blank=True)
    resume = models.FileField(upload_to='resumes/')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='under-review')
    applied_date = models.DateField(auto_now_add=True)
    last_update = models.DateField(auto_now=True)
    interview_date = models.DateField(null=True, blank=True)
```

## CORS Configuration

Don't forget to configure CORS in your Django settings:

```python
# settings.py

INSTALLED_APPS = [
    # ...
    'corsheaders',
]

MIDDLEWARE = [
    'corsheaders.middleware.CorsMiddleware',
    # ...
]

CORS_ALLOWED_ORIGINS = [
    "http://localhost:3000",
    "http://localhost:5173",
    # Add your production frontend URL
]
```

## Authentication

Use Django REST Framework with JWT tokens:

```bash
pip install djangorestframework djangorestframework-simplejwt
```

Store the JWT token in localStorage after login and include it in all API requests:

```javascript
// Example API call with token
fetch('http://your-django-backend/api/applications/', {
  method: 'GET',
  headers: {
    'Authorization': `Bearer ${localStorage.getItem('token')}`,
    'Content-Type': 'application/json',
  },
})
```

## Next Steps

1. Replace mock data in components with actual API calls
2. Add proper error handling for API failures
3. Implement loading states during API calls
4. Store authentication token in localStorage
5. Add token refresh logic for expired tokens
6. Implement proper file upload handling for resumes
7. Add form validation on both frontend and backend
8. Set up email service (SendGrid, Amazon SES, etc.)

## Environment Variables

Create a `.env` file for your API base URL:

```
VITE_API_BASE_URL=http://localhost:8000/api
```
